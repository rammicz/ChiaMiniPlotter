﻿## When using or sharing this script I am only asking you to have this message still in place
Write-host "#####################################################" -ForegroundColor Green -BackgroundColor Black
Write-host "##                                                 ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##   ChiaMiniPlotter.ps1 v1.0  by  JIRI HERNIK     ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##                                                 ##" -ForegroundColor Green -BackgroundColor Black
Write-host "## Need help setting up your own plotting machine? ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##     Contact me on on rammi.cz@gmail.com         ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##                                                 ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##   Have you farmed some Chia with this script?   ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##  It had cost me a blood and tears to write it.  ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##            Please consider donation.            ##" -ForegroundColor Green -BackgroundColor Black
Write-host "##                                                 ##" -ForegroundColor Green -BackgroundColor Black
Write-host "#####################################################" -ForegroundColor Green -BackgroundColor Black
Write-host ""
Write-host "Donation addresses:"
Write-host "XCH: xch1jen5pdwk8gh2cvntkk2rctzs4fl5gda2p39kzyavg778alpaxxzsje7t3u" 
Write-host "LTC: ltc1qax73qnnn2dd0e3e5htgluawun7kvrq60nwr62w"
Write-host "BTC: bc1qh7urn8upqn9cue9450f563ez4krncz7qa3cge2"
Write-host ""
Write-host "You can find latest version on "
Write-host "https://github.com/rammicz/ChiaMiniPlotter"
Write-host ""
Write-host "Initializing..."

$ErrorActionPreference = "Stop";
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
Push-Location $dir
$chiaPath = ""
$processes = @{}
$nextSpinup = @{}
function ChiaMiniPlotter()
{
    $target = ""
    $oldTarget = ""
    while($true)
    {
        $configFile = Get-Content -Raw -Path ".\ChiaMiniPlotter.json" -ErrorAction Stop
        $configJson = $configFile | ConvertFrom-Json

        $chiaPath = $configJson.chiapath
        foreach($checkTarget in $configJson.targets)
        {
            if(checkSpace -path $checkTarget -minimalFreeSpace 1000)
            {
                if($oldTarget -ne $checkTarget)
                {
                    Write-Host "Changing current target path to $checkTarget"
                    $target = $checkTarget
                }
                break
            }else {
                Write-Host "Not enough space on target"
            }
        }
        if($target -eq "")
        {
            Write-host "Not enough space on all targets, this is end" -ForegroundColor Red
            exit
        }
        
        $oldTarget = $target

        for($configReload=1; $configReload -le 10; $configReload++)
        {
            foreach($plotter in $configJson.plotters)
            {
                for($i=1; $i -le $plotter.plotters; $i++)
                {
                    runPlotter -ssd $plotter.ssd -instanceNumber $i -targetPath $target -spinupDelayMinutes $plotter.spinupMinutes -threads $plotter.threads -ram $plotter.ram
                }
            }
            
            start-sleep -s 10
        }
    }
}

function runPlotter()
{
    param (
        $ssd, $instanceNumber, $targetPath, $spinupDelayMinutes, $threads, $ram
    )
    $processKey = $ssd + $instanceNumber
    if($processes.ContainsKey($processKey))
    {
        $process = $processes[$processKey]
        if($process.HasExited)
        {
            $diff= New-TimeSpan -Start $process.StartTime -End $process.ExitTime
            if($process.ExitCode -eq 0)
            {
                write-host Finished $($processKey) " processing time: " $([Math]::Floor(($diff.TotalHours))):$([Math]::Round($diff.Minutes)) -ForegroundColor Green
            }else {
                write-host Failed $($processKey) "with exitcode $process.ExitCode processing time: " $([Math]::Floor(($diff.TotalHours))) : $([Math]::Round($diff.Minutes)) -ForegroundColor Red
            }
        }else {
            return
        }
    }
    
    if(!$nextSpinup.ContainsKey($ssd) -or (get-date $nextSpinup[$ssd]) -le (Get-Date))
    {
        $tempFolder = $($ssd) + ":\chia_" + $($instanceNumber)
        if (Test-Path -Path $tempFolder) {
            write-host removing $tempFolder -ForegroundColor Magenta
            rd $tempFolder -Recurse
        }

        if(checkspace -path $tempFolder -minimalFreeSpace 240)
        {
            $processes[$processKey] = createPlotterProcess -tempFolder $tempFolder -targetPath $targetPath -instanceNumber $instanceNumber -threads $threads -ram $ram
            $nextSpinup[$ssd] = (Get-Date).AddMinutes($spinupDelayMinutes)
        }else{
            write-host "Not enough free space on $diskLetter - $diskSpace GB of $minimalFreeSpace GB" -ForegroundColor red
        }
    }
}

function createPlotterProcess()
{
    param (
        $tempFolder, $targetPath, $instanceNumber, $threads, $ram
    )
    $process = start-process $chiaPath -ArgumentList "plots create -k 32 -r $threads -b $ram -t $tempFolder -d $targetPath" -passthru
    $date = Get-Date -Format("yyyy-MM-dd HH:mm:ss")
    write-host $($date)  - STARTED $($processKey) PID: $($process.Id) -ForegroundColor Green
    return $process
}

function checkSpace()
{
    param ($path, $minimalFreeSpace)

    $diskLetter = $path.substring(0,1).ToUpper()
    if($diskLetter -ne "\")
    {
        $filter = "DeviceID='" + $diskLetter + ":'"
        $disk = Get-CimInstance Win32_LogicalDisk -Filter $filter
        $diskspace = [Math]::Round($disk.FreeSpace / 1GB) 
        if($diskspace -le $minimalFreeSpace)
        {
            return $false
        }
    }

    return $true
}

ChiaMiniPlotter